from __future__ import annotations

from PIL import Image

from badloom_manga.crop_background_profile import (
    PageBackgroundProfile,
    classify_page_background,
)

from .diagnostics import DiagnosticsCollector, emit


def analyze_background(
    source: Image.Image,
    diagnostics: DiagnosticsCollector | None = None,
) -> PageBackgroundProfile:
    profile = classify_page_background(source)
    emit(
        diagnostics,
        "background",
        "BACKGROUND_CLASSIFIED",
        "Page canvas profile resolved",
        details={
            "mode": profile.mode.value,
            "luminance": profile.luminance,
            "spread": profile.spread,
            "confidence": profile.confidence,
        },
    )
    return profile


__all__ = ["analyze_background"]
