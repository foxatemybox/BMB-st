from __future__ import annotations

from math import ceil, floor

from PIL import Image

from badloom_manga import crop_column_detection as legacy_columns
from badloom_manga.crop_background_profile import PageBackgroundProfile
from badloom_manga.crop_row_analysis import background_aware_ink_mask

from .contract import CoarseRow, PanelHypothesis
from .diagnostics import DiagnosticsCollector, emit
from .settings import FrameAnalysisSettings


def split_horizontal_panels(
    source: Image.Image,
    rows: tuple[CoarseRow, ...],
    background: PageBackgroundProfile,
    settings: FrameAnalysisSettings,
    diagnostics: DiagnosticsCollector | None = None,
) -> tuple[PanelHypothesis, ...]:
    """Split rows only; final outer-side fitting belongs to side_refine."""

    if not rows:
        return ()
    config = settings.normalized()
    split = config.horizontal_split
    legacy = legacy_columns.HorizontalPanelSettings(
        analysis_width=config.analysis_width,
        minimum_gap_source=split.minimum_gap_source,
        maximum_gap_fraction=split.maximum_gap_fraction,
        minimum_panel_source=split.minimum_panel_source,
        minimum_panel_fraction=split.minimum_panel_fraction,
        gap_activity=split.gap_activity,
        panel_activity=split.panel_activity,
        flank_activity=split.flank_activity,
        alignment_tolerance=split.alignment_tolerance,
    ).normalized()

    target_width = max(128, min(config.analysis_width, source.width))
    scale_x = target_width / max(1, source.width)
    target_height = max(1, int(round(source.height * scale_x)))
    reduced = source.resize((target_width, target_height), Image.Resampling.BOX)
    mask = None
    output: list[PanelHypothesis] = []
    try:
        mask = background_aware_ink_mask(reduced, background)
        scale_y = target_height / max(1, source.height)
        for row_index, row in enumerate(rows):
            top = max(0, min(target_height - 1, int(floor(row.top * scale_y))))
            bottom = max(top + 1, min(target_height, int(ceil(row.bottom * scale_y))))
            band = mask.crop((0, top, target_width, bottom))
            try:
                # This is the proven Current split decision only. Its old
                # outer-edge and rule snap passes are deliberately not called.
                spans = legacy_columns._panel_spans(
                    band,
                    source.width,
                    scale_x,
                    legacy,
                )
            finally:
                band.close()

            resolved_spans = list(reversed(spans)) if len(spans) >= 2 else [(0, source.width)]
            decision = f"same_row:{len(resolved_spans)}" if len(spans) >= 2 else "single"
            for left, right in resolved_spans:
                output.append(
                    PanelHypothesis(
                        row_index=row_index,
                        top=row.top,
                        bottom=row.bottom,
                        left_top=int(left),
                        right_top=int(right),
                        right_bottom=int(right),
                        left_bottom=int(left),
                        confidence=row.confidence,
                        split_decision=decision,
                    )
                )
            emit(
                diagnostics,
                "horizontal_split",
                "ROW_SPLIT" if len(spans) >= 2 else "ROW_KEPT_SINGLE",
                "Horizontal panel split decision completed",
                details={
                    "row_index": row_index,
                    "top": row.top,
                    "bottom": row.bottom,
                    "panels": len(resolved_spans),
                },
            )
        return tuple(output)
    finally:
        if mask is not None:
            mask.close()
        reduced.close()


__all__ = ["split_horizontal_panels"]
