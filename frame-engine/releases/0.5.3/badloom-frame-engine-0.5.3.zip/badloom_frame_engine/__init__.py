from .contract import (
    AnalysisQuad,
    CoarseRow,
    DiagnosticEvent,
    FrameAnalysisCandidate,
    FrameEvidence,
    PageAnalysisResult,
    PanelHypothesis,
)
from .pipeline import ENGINE_API, ENGINE_CHANGELOG, ENGINE_VERSION, analyze_page_v05
from .settings import (
    FrameAnalysisSettings,
    HorizontalSplitSettings,
    SideRefineSettings,
)

# External bundles and the built-in engine expose the same provider symbol.
analyze_page = analyze_page_v05

__all__ = [
    "AnalysisQuad",
    "CoarseRow",
    "DiagnosticEvent",
    "ENGINE_API",
    "ENGINE_CHANGELOG",
    "ENGINE_VERSION",
    "FrameAnalysisCandidate",
    "FrameAnalysisSettings",
    "FrameEvidence",
    "HorizontalSplitSettings",
    "PageAnalysisResult",
    "PanelHypothesis",
    "SideRefineSettings",
    "analyze_page",
    "analyze_page_v05",
]
