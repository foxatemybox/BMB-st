from __future__ import annotations

from dataclasses import dataclass
from math import ceil, floor
from statistics import median

from PIL import Image

from badloom_manga.crop_background_profile import PageBackgroundProfile
from badloom_manga.crop_row_analysis import row_analysis_profiles

from .contract import CoarseRow
from .diagnostics import DiagnosticsCollector, emit
from .settings import FrameAnalysisSettings


@dataclass(frozen=True, slots=True)
class RowProfiles:
    ink: tuple[float, ...]
    structure: tuple[float, ...]
    saturation: tuple[float, ...]
    edge: tuple[float, ...]
    activity: tuple[float, ...]
    scale: float


def detect_coarse_rows(
    source: Image.Image,
    background: PageBackgroundProfile,
    settings: FrameAnalysisSettings,
    diagnostics: DiagnosticsCollector | None = None,
) -> tuple[RowProfiles, tuple[CoarseRow, ...]]:
    """Detect Y-runs only; this stage never decides X geometry."""

    config = settings.normalized()
    ink, structure, saturation, edge, scale, measured_background = row_analysis_profiles(
        source,
        analysis_width=config.analysis_width,
    )
    if measured_background.mode is not background.mode:
        emit(
            diagnostics,
            "coarse_rows",
            "BACKGROUND_RECHECK_DIFFERED",
            "Row analyzer returned a different canvas mode",
            details={
                "pipeline": background.mode.value,
                "row_analysis": measured_background.mode.value,
            },
        )

    activity = tuple(
        max(
            float(ink_value),
            float(structure_value) * 0.82,
            float(saturation_value) * 0.34,
            float(edge_value) * 0.88,
        )
        for ink_value, structure_value, saturation_value, edge_value in zip(
            ink,
            structure,
            saturation,
            edge,
        )
    )
    threshold = config.active_threshold
    active = [value >= threshold for value in activity]
    close_gap = max(0, int(round(config.close_gap_source * scale)))
    if close_gap:
        active = _close_short_gaps(active, close_gap)

    minimum_height = max(2, int(round(config.minimum_height_source * scale)))
    analysis_runs = [
        (start, end)
        for start, end in _runs(active)
        if end - start >= minimum_height
    ]
    rows: list[CoarseRow] = []
    for start, end in analysis_runs:
        values = sorted(activity[start:end])
        typical = float(median(values)) if values else threshold
        confidence = max(0.05, min(1.0, 0.42 + typical / max(threshold, 1e-9) * 0.16))
        source_top = max(0, min(source.height - 1, int(floor(start / scale))))
        source_bottom = max(
            source_top + 1,
            min(source.height, int(ceil(end / scale))),
        )
        rows.append(
            CoarseRow(
                top=source_top,
                bottom=source_bottom,
                confidence=confidence,
                evidence=(
                    ("analysis_top", float(start)),
                    ("analysis_bottom", float(end)),
                    ("typical_activity", typical),
                    ("active_threshold", threshold),
                ),
            )
        )

    emit(
        diagnostics,
        "coarse_rows",
        "COARSE_ROWS_DETECTED" if rows else "NO_COARSE_ROWS",
        "Coarse vertical frame hypotheses resolved",
        details={
            "count": len(rows),
            "scale": scale,
            "threshold": threshold,
            "minimum_height_analysis": minimum_height,
        },
    )
    return (
        RowProfiles(
            ink=tuple(float(value) for value in ink),
            structure=tuple(float(value) for value in structure),
            saturation=tuple(float(value) for value in saturation),
            edge=tuple(float(value) for value in edge),
            activity=activity,
            scale=float(scale),
        ),
        tuple(rows),
    )


def _close_short_gaps(values: list[bool], maximum_gap: int) -> list[bool]:
    closed = list(values)
    for start, end in _runs([not value for value in values]):
        if start == 0 or end == len(values):
            continue
        if end - start <= maximum_gap and values[start - 1] and values[end]:
            closed[start:end] = [True] * (end - start)
    return closed


def _runs(values: list[bool]) -> list[tuple[int, int]]:
    output: list[tuple[int, int]] = []
    start: int | None = None
    for index, value in enumerate(values):
        if value and start is None:
            start = index
        if start is not None and (not value or index == len(values) - 1):
            end = index if not value else index + 1
            output.append((start, end))
            start = None
    return output


__all__ = ["RowProfiles", "detect_coarse_rows"]
