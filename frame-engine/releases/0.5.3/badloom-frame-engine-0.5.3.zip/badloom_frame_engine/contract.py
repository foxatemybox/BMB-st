from __future__ import annotations

from dataclasses import dataclass, field
from math import isfinite
from typing import Mapping

from badloom_manga.crop_background_profile import PageBackgroundProfile


Point = tuple[float, float]


@dataclass(frozen=True, slots=True)
class AnalysisQuad:
    """Frame geometry owned by the 0.5 analyzer, in source-image pixels."""

    top_left: Point
    top_right: Point
    bottom_right: Point
    bottom_left: Point

    def __post_init__(self) -> None:
        coordinates = (
            *self.top_left,
            *self.top_right,
            *self.bottom_right,
            *self.bottom_left,
        )
        if not all(isfinite(float(value)) for value in coordinates):
            raise ValueError("quad coordinates must be finite")
        if self.top_right[0] <= self.top_left[0]:
            raise ValueError("quad top side must have positive width")
        if self.bottom_right[0] <= self.bottom_left[0]:
            raise ValueError("quad bottom side must have positive width")
        if max(self.bottom_left[1], self.bottom_right[1]) <= min(
            self.top_left[1], self.top_right[1]
        ):
            raise ValueError("quad must have positive height")

    @property
    def centre_x(self) -> float:
        return sum(
            point[0]
            for point in (
                self.top_left,
                self.top_right,
                self.bottom_right,
                self.bottom_left,
            )
        ) / 4.0


@dataclass(frozen=True, slots=True)
class CoarseRow:
    top: int
    bottom: int
    confidence: float
    evidence: tuple[tuple[str, float], ...] = ()

    def __post_init__(self) -> None:
        if self.top < 0 or self.bottom <= self.top:
            raise ValueError("coarse row must have positive source-space height")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("coarse row confidence must be between zero and one")


@dataclass(frozen=True, slots=True)
class PanelHypothesis:
    row_index: int
    top: int
    bottom: int
    left_top: int
    right_top: int
    right_bottom: int
    left_bottom: int
    confidence: float
    split_decision: str = "single"
    reason_codes: tuple[str, ...] = ()

    @property
    def centre_x(self) -> float:
        return (
            self.left_top
            + self.right_top
            + self.right_bottom
            + self.left_bottom
        ) / 4.0

    def to_quad(self) -> AnalysisQuad:
        return AnalysisQuad(
            top_left=(float(self.left_top), float(self.top)),
            top_right=(float(self.right_top), float(self.top)),
            bottom_right=(float(self.right_bottom), float(self.bottom)),
            bottom_left=(float(self.left_bottom), float(self.bottom)),
        )


@dataclass(frozen=True, slots=True)
class FrameEvidence:
    coarse_row: tuple[int, int]
    horizontal_split: str
    left_side: str
    right_side: str
    reason_codes: tuple[str, ...] = ()
    metrics: tuple[tuple[str, float], ...] = ()


@dataclass(frozen=True, slots=True)
class FrameAnalysisCandidate:
    frame_key: str
    quad: AnalysisQuad
    confidence: float
    order_key: tuple[int, float]
    evidence: FrameEvidence

    def __post_init__(self) -> None:
        if not self.frame_key:
            raise ValueError("frame_key must not be empty")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("candidate confidence must be between zero and one")


@dataclass(frozen=True, slots=True)
class DiagnosticEvent:
    stage: str
    code: str
    message: str
    frame_key: str | None = None
    details: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class PageAnalysisResult:
    width: int
    height: int
    background: PageBackgroundProfile
    frames: tuple[FrameAnalysisCandidate, ...]
    diagnostics: tuple[DiagnosticEvent, ...] = ()
    engine_api: str = "0.5"
    engine_version: str = "0.5.0"

    def __post_init__(self) -> None:
        if self.width < 1 or self.height < 1:
            raise ValueError("page dimensions must be positive")


__all__ = [
    "AnalysisQuad",
    "CoarseRow",
    "DiagnosticEvent",
    "FrameAnalysisCandidate",
    "FrameEvidence",
    "PageAnalysisResult",
    "PanelHypothesis",
    "Point",
]
