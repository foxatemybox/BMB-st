from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class HorizontalSplitSettings:
    minimum_gap_source: int = 8
    maximum_gap_fraction: float = 0.14
    minimum_panel_source: int = 72
    minimum_panel_fraction: float = 0.14
    gap_activity: float = 0.040
    panel_activity: float = 0.085
    flank_activity: float = 0.12
    alignment_tolerance: float = 0.10


@dataclass(frozen=True, slots=True)
class SideRefineSettings:
    minimum_coverage: float = 0.52
    maximum_residual_source: float = 6.0
    ordinary_search_fraction: float = 0.075
    page_edge_search_fraction: float = 0.35
    maximum_search_source: int = 2048
    outward_tolerance_source: int = 6
    minimum_frame_width_source: int = 24


@dataclass(frozen=True, slots=True)
class FrameAnalysisSettings:
    analysis_width: int = 448
    sensitivity: int = 68
    minimum_height_source: int = 72
    close_gap_source: int = 10
    panel_rule_refinement: bool = True
    horizontal_split: HorizontalSplitSettings = field(
        default_factory=HorizontalSplitSettings
    )
    side_refine: SideRefineSettings = field(default_factory=SideRefineSettings)

    def normalized(self) -> "FrameAnalysisSettings":
        return FrameAnalysisSettings(
            analysis_width=max(128, min(1024, int(self.analysis_width))),
            sensitivity=max(1, min(100, int(self.sensitivity))),
            minimum_height_source=max(8, min(10000, int(self.minimum_height_source))),
            close_gap_source=max(0, min(512, int(self.close_gap_source))),
            panel_rule_refinement=bool(self.panel_rule_refinement),
            horizontal_split=self.horizontal_split,
            side_refine=self.side_refine,
        )

    @property
    def active_threshold(self) -> float:
        normalized = self.normalized()
        return max(0.006, min(0.055, 0.048 - normalized.sensitivity * 0.00052))


__all__ = [
    "FrameAnalysisSettings",
    "HorizontalSplitSettings",
    "SideRefineSettings",
]
