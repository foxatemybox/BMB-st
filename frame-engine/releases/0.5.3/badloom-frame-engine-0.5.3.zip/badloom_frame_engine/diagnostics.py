from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Protocol
import json
import threading

from .contract import DiagnosticEvent


class DiagnosticsCollector(Protocol):
    def record(self, event: DiagnosticEvent) -> None: ...


class ListDiagnosticsCollector:
    def __init__(self) -> None:
        self.events: list[DiagnosticEvent] = []

    def record(self, event: DiagnosticEvent) -> None:
        self.events.append(event)


class JsonlDiagnosticsCollector:
    """Append explainable 0.5 decisions beside the existing processing trace."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock = threading.Lock()

    def record(self, event: DiagnosticEvent) -> None:
        payload = {
            "stage": event.stage,
            "code": event.code,
            "message": event.message,
            "frame_key": event.frame_key,
            "details": dict(event.details),
        }
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(encoded + "\n")


class FanoutDiagnosticsCollector:
    def __init__(self, *collectors: DiagnosticsCollector) -> None:
        self.collectors = tuple(collectors)

    def record(self, event: DiagnosticEvent) -> None:
        for collector in self.collectors:
            try:
                collector.record(event)
            except Exception:
                continue


def emit(
    collector: DiagnosticsCollector | None,
    stage: str,
    code: str,
    message: str,
    *,
    frame_key: str | None = None,
    details: Mapping[str, object] | None = None,
) -> None:
    if collector is None:
        return
    try:
        collector.record(
            DiagnosticEvent(
                stage=stage,
                code=code,
                message=message,
                frame_key=frame_key,
                details=dict(details or {}),
            )
        )
    except Exception:
        return


__all__ = [
    "DiagnosticsCollector",
    "FanoutDiagnosticsCollector",
    "JsonlDiagnosticsCollector",
    "ListDiagnosticsCollector",
    "emit",
]
