from __future__ import annotations

import hashlib

from .contract import (
    FrameAnalysisCandidate,
    FrameEvidence,
    PanelHypothesis,
)
from .diagnostics import DiagnosticsCollector, emit


def assemble_candidates(
    panels: tuple[PanelHypothesis, ...],
    diagnostics: DiagnosticsCollector | None = None,
) -> tuple[FrameAnalysisCandidate, ...]:
    """Create immutable analyzer-owned candidates in manga reading order."""

    ordered = sorted(panels, key=lambda panel: (panel.row_index, -panel.centre_x))
    output: list[FrameAnalysisCandidate] = []
    seen: dict[str, int] = {}
    for panel in ordered:
        quad = panel.to_quad()
        geometry = "|".join(
            f"{value:.3f}"
            for point in (
                quad.top_left,
                quad.top_right,
                quad.bottom_right,
                quad.bottom_left,
            )
            for value in point
        )
        digest = hashlib.sha256(geometry.encode("ascii")).hexdigest()[:16]
        duplicate = seen.get(digest, 0)
        seen[digest] = duplicate + 1
        frame_key = f"v05-{digest}" + (f"-{duplicate + 1}" if duplicate else "")
        left_code = next(
            (code.split(":", 1)[1] for code in panel.reason_codes if code.startswith("left:")),
            "UNRESOLVED",
        )
        right_code = next(
            (code.split(":", 1)[1] for code in panel.reason_codes if code.startswith("right:")),
            "UNRESOLVED",
        )
        candidate = FrameAnalysisCandidate(
            frame_key=frame_key,
            quad=quad,
            confidence=panel.confidence,
            order_key=(panel.row_index, -quad.centre_x),
            evidence=FrameEvidence(
                coarse_row=(panel.top, panel.bottom),
                horizontal_split=panel.split_decision,
                left_side=left_code,
                right_side=right_code,
                reason_codes=panel.reason_codes,
            ),
        )
        output.append(candidate)
        emit(
            diagnostics,
            "ordering",
            "CANDIDATE_ASSEMBLED",
            "Final analyzer candidate assembled",
            frame_key=frame_key,
            details={
                "order_key": list(candidate.order_key),
                "confidence": candidate.confidence,
                "quad": [
                    list(quad.top_left),
                    list(quad.top_right),
                    list(quad.bottom_right),
                    list(quad.bottom_left),
                ],
            },
        )
    return tuple(output)


__all__ = ["assemble_candidates"]
