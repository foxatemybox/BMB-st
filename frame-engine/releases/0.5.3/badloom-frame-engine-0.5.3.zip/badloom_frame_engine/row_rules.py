from __future__ import annotations

from dataclasses import dataclass
from math import ceil, floor

from PIL import Image

from badloom_manga.crop_panel_rule_refinement import refine_runs_at_panel_rules

from .coarse_rows import RowProfiles
from .contract import CoarseRow
from .diagnostics import DiagnosticsCollector, emit
from .settings import FrameAnalysisSettings


@dataclass(frozen=True, slots=True)
class _HorizontalRuleSnap:
    coordinate: int
    distance: int
    coverage: float
    thickness: int
    tone: str


def _snap_horizontal_rule_edge(
    source: Image.Image,
    coordinate: int,
    *,
    opposite: int,
) -> _HorizontalRuleSnap | None:
    """Snap one coarse horizontal frame edge onto a nearby persistent rule band.

    Row refinement remains the only owner of Y geometry. The search is narrow
    and source-space: it can align the crop to an existing panel border, but an
    ordinary internal artwork stripe cannot take ownership of the frame edge.
    """

    width, height = source.size
    coordinate = max(0, min(height, int(coordinate)))
    opposite = max(0, min(height, int(opposite)))
    frame_height = abs(opposite - coordinate)
    if width < 32 or height < 16 or frame_height < 16:
        return None

    search = max(8, min(48, int(round(frame_height * 0.055))))
    window_top = max(0, coordinate - search)
    window_bottom = min(height, coordinate + search + 1)
    if window_bottom - window_top < 5:
        return None

    target_width = max(96, min(448, width))
    crop = source.crop((0, window_top, width, window_bottom)).convert("L")
    reduced = None
    dark = None
    light = None
    try:
        reduced = (
            crop.copy()
            if crop.width == target_width
            else crop.resize((target_width, crop.height), Image.Resampling.BOX)
        )
        dark = reduced.point(lambda value: 255 if value <= 78 else 0, mode="L")
        light = reduced.point(lambda value: 255 if value >= 244 else 0, mode="L")
        dark_profile = _row_fraction(dark)
        light_profile = _row_fraction(light)
        luminance_profile = _row_mean(reduced)

        maximum_thickness = max(3, min(18, int(round(width * 0.012))))
        candidates: list[_HorizontalRuleSnap] = []
        for tone, profile in (("dark", dark_profile), ("light", light_profile)):
            active = [value >= 0.42 for value in profile]
            for start, end in _runs(active):
                thickness = end - start
                if thickness < 1 or thickness > maximum_thickness:
                    continue
                center_local = int(round((start + end - 1) / 2.0))
                center = window_top + center_local
                distance = abs(center - coordinate)
                if distance > search:
                    continue
                coverage = max(profile[start:end], default=0.0)
                if coverage < 0.42:
                    continue
                band_luminance = sum(luminance_profile[start:end]) / thickness
                flank_contrast = _flank_contrast(
                    luminance_profile,
                    start,
                    end,
                    band_luminance,
                )
                if flank_contrast < 26.0:
                    continue
                candidates.append(
                    _HorizontalRuleSnap(
                        coordinate=center,
                        distance=distance,
                        coverage=float(coverage),
                        thickness=thickness,
                        tone=tone,
                    )
                )
        if not candidates:
            return None

        inward_sign = 1 if opposite > coordinate else -1
        return max(
            candidates,
            key=lambda item: (
                -item.distance,
                int((item.coordinate - coordinate) * inward_sign >= 0),
                item.coverage,
                -item.thickness,
            ),
        )
    finally:
        for image in (light, dark, reduced, crop):
            if image is not None:
                image.close()


def _row_fraction(mask: Image.Image) -> list[float]:
    profile = mask.resize((1, mask.height), Image.Resampling.BOX)
    try:
        values = (
            profile.get_flattened_data()
            if hasattr(profile, "get_flattened_data")
            else profile.getdata()
        )
        return [float(value) / 255.0 for value in values]
    finally:
        profile.close()


def _row_mean(image: Image.Image) -> list[float]:
    profile = image.resize((1, image.height), Image.Resampling.BOX)
    try:
        values = (
            profile.get_flattened_data()
            if hasattr(profile, "get_flattened_data")
            else profile.getdata()
        )
        return [float(value) for value in values]
    finally:
        profile.close()


def _flank_contrast(
    profile: list[float],
    start: int,
    end: int,
    band_luminance: float,
) -> float:
    probe = max(2, min(8, (end - start) * 2))
    before = profile[max(0, start - probe) : start]
    after = profile[end : min(len(profile), end + probe)]
    contrasts = []
    if before:
        contrasts.append(abs(band_luminance - sum(before) / len(before)))
    if after:
        contrasts.append(abs(band_luminance - sum(after) / len(after)))
    return max(contrasts, default=0.0)


def _runs(values: list[bool]) -> list[tuple[int, int]]:
    output: list[tuple[int, int]] = []
    start: int | None = None
    for index, value in enumerate(values):
        if value and start is None:
            start = index
        elif not value and start is not None:
            output.append((start, index))
            start = None
    if start is not None:
        output.append((start, len(values)))
    return output


def refine_rows_at_panel_rules(
    source: Image.Image,
    rows: tuple[CoarseRow, ...],
    profiles: RowProfiles,
    settings: FrameAnalysisSettings,
    diagnostics: DiagnosticsCollector | None = None,
) -> tuple[CoarseRow, ...]:
    if not rows or not settings.panel_rule_refinement:
        return rows

    scale = max(float(profiles.scale), 1e-9)
    analysis_runs = [
        (
            max(0, int(floor(row.top * scale))),
            min(len(profiles.ink), int(ceil(row.bottom * scale))),
        )
        for row in rows
    ]
    resolved = refine_runs_at_panel_rules(
        source,
        analysis_runs,
        profiles.ink,
        profiles.structure,
        scale,
        active_threshold=settings.active_threshold,
        minimum_height_source=settings.minimum_height_source,
    )
    output: list[CoarseRow] = []
    snapped_edges = 0
    minimum_height = max(1, int(settings.minimum_height_source))
    for start, end in resolved:
        top = max(0, min(source.height - 1, int(floor(start / scale))))
        bottom = max(top + 1, min(source.height, int(ceil(end / scale))))
        raw_top = top

        top_snap = _snap_horizontal_rule_edge(
            source,
            top,
            opposite=bottom,
        )
        if (
            top_snap is not None
            and bottom - top_snap.coordinate >= minimum_height
        ):
            top = top_snap.coordinate
            snapped_edges += int(top != raw_top)
            if top != raw_top:
                emit(
                    diagnostics,
                    "row_rules",
                    "PANEL_RULE_EDGE_SNAPPED",
                    "Top frame edge aligned to an existing panel rule",
                    details={
                        "edge": "top",
                        "from": raw_top,
                        "to": top,
                        "distance": top_snap.distance,
                        "coverage": round(top_snap.coverage, 4),
                        "thickness": top_snap.thickness,
                        "tone": top_snap.tone,
                    },
                )

        bottom_snap = _snap_horizontal_rule_edge(
            source,
            bottom,
            opposite=top,
        )
        if (
            bottom_snap is not None
            and bottom_snap.coordinate - top >= minimum_height
        ):
            previous_bottom = bottom
            bottom = bottom_snap.coordinate
            snapped_edges += int(bottom != previous_bottom)
            if bottom != previous_bottom:
                emit(
                    diagnostics,
                    "row_rules",
                    "PANEL_RULE_EDGE_SNAPPED",
                    "Bottom frame edge aligned to an existing panel rule",
                    details={
                        "edge": "bottom",
                        "from": previous_bottom,
                        "to": bottom,
                        "distance": bottom_snap.distance,
                        "coverage": round(bottom_snap.coverage, 4),
                        "thickness": bottom_snap.thickness,
                        "tone": bottom_snap.tone,
                    },
                )

        overlaps = [
            row
            for row in rows
            if min(row.bottom, bottom) > max(row.top, top)
        ]
        confidence = max((row.confidence for row in overlaps), default=0.55)
        output.append(
            CoarseRow(
                top=top,
                bottom=bottom,
                confidence=confidence,
                evidence=(("panel_rule_refined", 1.0),),
            )
        )

    emit(
        diagnostics,
        "row_rules",
        "PANEL_RULE_ROWS_REFINED",
        "Panel-rule refinement completed",
        details={
            "before": len(rows),
            "after": len(output),
            "snapped_edges": snapped_edges,
        },
    )
    return tuple(output)


__all__ = ["refine_rows_at_panel_rules"]
