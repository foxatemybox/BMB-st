from __future__ import annotations

from dataclasses import dataclass, replace
from math import ceil
from statistics import median

from PIL import Image

from badloom_manga.crop_background_profile import PageBackgroundProfile
from badloom_manga.crop_row_analysis import background_aware_ink_mask

from .contract import PanelHypothesis
from .diagnostics import DiagnosticsCollector, emit
from .settings import FrameAnalysisSettings, SideRefineSettings


NO_POINTS = "NO_POINTS"
INSUFFICIENT_COVERAGE = "INSUFFICIENT_COVERAGE"
RESIDUAL_TOO_HIGH = "RESIDUAL_TOO_HIGH"
SEARCH_LIMIT = "SEARCH_LIMIT"
OUTWARD_MOVE_REJECTED = "OUTWARD_MOVE_REJECTED"
OUTWARD_RULE_ACCEPTED = "OUTWARD_RULE_ACCEPTED"
PAGE_EDGE_CANVAS_REJECTED = "PAGE_EDGE_CANVAS_REJECTED"
PAGE_EDGE_CONTINUATION_ACCEPTED = "PAGE_EDGE_CONTINUATION_ACCEPTED"
MINIMUM_FRAME_WIDTH = "MINIMUM_FRAME_WIDTH"
ACCEPTED = "ACCEPTED"
UNCHANGED = "UNCHANGED"


@dataclass(frozen=True, slots=True)
class SideLineDecision:
    top: int | None
    bottom: int | None
    code: str
    points: int = 0
    coverage: float = 0.0
    residual: float | None = None

    @property
    def resolved(self) -> bool:
        return self.top is not None and self.bottom is not None


def source_resolution_side_line(
    source: Image.Image,
    background: PageBackgroundProfile,
    *,
    top: int,
    bottom: int,
    coarse_top: int,
    coarse_bottom: int,
    edge: str,
    settings: SideRefineSettings,
    allow_page_edge_recovery: bool = False,
) -> SideLineDecision:
    """Resolve one panel side at source X resolution.

    Reduced masks may provide a coarse span that is either wider *or narrower*
    than the real panel. The final X owner therefore first looks for a
    persistent page-canvas/panel transition on both sides of the coarse line.
    Only when no such transition can be fitted does it fall back to the older
    inward ink-boundary fit. This lets a narrow coarse span expand back to a
    real panel rule without allowing a local balloon/SFX to own the side.
    """

    if edge not in {"left", "right"}:
        raise ValueError("edge must be left or right")
    width, height = source.size
    top = max(0, min(height - 1, int(top)))
    bottom = max(top + 1, min(height, int(bottom)))
    if width < 16 or bottom - top < 16:
        return SideLineDecision(None, None, INSUFFICIENT_COVERAGE)

    coarse_top = max(0, min(width, int(coarse_top)))
    coarse_bottom = max(0, min(width, int(coarse_bottom)))
    ordinary_search = max(18, int(round(width * settings.ordinary_search_fraction)))
    transition_fraction = max(
        float(settings.ordinary_search_fraction),
        float(getattr(settings, "outward_search_fraction", 0.18)),
    )
    transition_search = max(ordinary_search, int(round(width * transition_fraction)))
    page_edge_coarse = (
        edge == "left" and min(coarse_top, coarse_bottom) <= 6
    ) or (
        edge == "right" and max(coarse_top, coarse_bottom) >= width - 6
    )
    if page_edge_coarse:
        ordinary_search = max(
            ordinary_search,
            int(round(width * settings.page_edge_search_fraction)),
        )
        transition_search = max(transition_search, ordinary_search)
    ordinary_search = max(
        12,
        min(int(settings.maximum_search_source), ordinary_search),
    )
    transition_search = max(
        12,
        min(int(settings.maximum_search_source), transition_search),
    )

    band = source.crop((0, top, width, bottom))
    reduced = None
    mask = None
    try:
        target_height = max(96, min(448, band.height))
        reduced = (
            band.copy()
            if band.height == target_height
            else band.resize((width, target_height), Image.Resampling.BOX)
        )

        if (
            allow_page_edge_recovery
            and not page_edge_coarse
            and _page_edge_continuation_support(
                reduced,
                background,
                edge=edge,
                coarse_top=coarse_top,
                coarse_bottom=coarse_bottom,
            )
        ):
            physical = 0 if edge == "left" else width
            return SideLineDecision(
                physical,
                physical,
                PAGE_EDGE_CONTINUATION_ACCEPTED,
                points=target_height,
                coverage=1.0,
                residual=0.0,
            )

        transition = _canvas_transition_side_line(
            reduced,
            background,
            coarse_top=coarse_top,
            coarse_bottom=coarse_bottom,
            edge=edge,
            search=transition_search,
            settings=settings,
        )
        if transition is not None:
            final_top, final_bottom, residual, retained = transition
            final_top = max(0, min(width, int(round(final_top))))
            final_bottom = max(0, min(width, int(round(final_bottom))))
            if (
                abs(final_top - coarse_top) <= transition_search
                and abs(final_bottom - coarse_bottom) <= transition_search
            ):
                if page_edge_coarse and not _page_edge_canvas_support(
                    reduced,
                    background,
                    edge=edge,
                    coarse_top=coarse_top,
                    coarse_bottom=coarse_bottom,
                    final_top=final_top,
                    final_bottom=final_bottom,
                ):
                    return SideLineDecision(
                        None,
                        None,
                        PAGE_EDGE_CANVAS_REJECTED,
                        points=retained,
                        coverage=retained / target_height,
                        residual=residual,
                    )
                tolerance = max(0, int(settings.outward_tolerance_source))
                outward = _maximum_outward_move(
                    edge,
                    coarse_top,
                    coarse_bottom,
                    final_top,
                    final_bottom,
                )
                code = (
                    OUTWARD_RULE_ACCEPTED
                    if outward > tolerance
                    else UNCHANGED
                    if (final_top, final_bottom) == (coarse_top, coarse_bottom)
                    else ACCEPTED
                )
                return SideLineDecision(
                    final_top,
                    final_bottom,
                    code,
                    points=retained,
                    coverage=retained / target_height,
                    residual=residual,
                )

        mask = background_aware_ink_mask(reduced, background)
        pixels = mask.load()
        points: list[tuple[float, float]] = []
        denominator = max(1, target_height - 1)
        for y in range(target_height):
            fraction = y / denominator
            predicted = float(coarse_top) + (
                float(coarse_bottom) - float(coarse_top)
            ) * fraction
            if edge == "left":
                start = max(0, int(round(predicted)) - 5)
                end = min(width, int(round(predicted)) + ordinary_search + 1)
                candidate = next(
                    (
                        x
                        for x in range(start, end)
                        if int(pixels[x, y]) >= 128
                    ),
                    None,
                )
            else:
                start = max(0, int(round(predicted)) - ordinary_search)
                end = min(width, int(round(predicted)) + 6)
                candidate = next(
                    (
                        x + 1
                        for x in range(end - 1, start - 1, -1)
                        if int(pixels[x, y]) >= 128
                    ),
                    None,
                )
            if candidate is not None:
                points.append((float(y), float(candidate)))

        minimum_points = max(12, int(ceil(target_height * settings.minimum_coverage)))
        if not points:
            return SideLineDecision(None, None, NO_POINTS)
        if len(points) < minimum_points:
            return SideLineDecision(
                None,
                None,
                INSUFFICIENT_COVERAGE,
                points=len(points),
                coverage=len(points) / target_height,
            )

        fitted = _fit_line(
            points,
            target_height,
            minimum_points=minimum_points,
            maximum_residual=float(settings.maximum_residual_source),
        )
        if fitted is None:
            return SideLineDecision(
                None,
                None,
                RESIDUAL_TOO_HIGH,
                points=len(points),
                coverage=len(points) / target_height,
            )
        fitted_top, fitted_bottom, residual, retained = fitted
        final_top = int(round(fitted_top))
        final_bottom = int(round(fitted_bottom))
        tolerance = max(0, int(settings.outward_tolerance_source))

        if _maximum_outward_move(
            edge,
            coarse_top,
            coarse_bottom,
            final_top,
            final_bottom,
        ) > tolerance:
            return SideLineDecision(
                None,
                None,
                OUTWARD_MOVE_REJECTED,
                points=retained,
                coverage=retained / target_height,
                residual=residual,
            )
        if (
            abs(final_top - coarse_top) > ordinary_search
            or abs(final_bottom - coarse_bottom) > ordinary_search
        ):
            return SideLineDecision(
                None,
                None,
                SEARCH_LIMIT,
                points=retained,
                coverage=retained / target_height,
                residual=residual,
            )

        final_top = max(0, min(width, final_top))
        final_bottom = max(0, min(width, final_bottom))
        if page_edge_coarse and not _page_edge_canvas_support(
            reduced,
            background,
            edge=edge,
            coarse_top=coarse_top,
            coarse_bottom=coarse_bottom,
            final_top=final_top,
            final_bottom=final_bottom,
        ):
            return SideLineDecision(
                None,
                None,
                PAGE_EDGE_CANVAS_REJECTED,
                points=retained,
                coverage=retained / target_height,
                residual=residual,
            )
        code = (
            UNCHANGED
            if (final_top, final_bottom) == (coarse_top, coarse_bottom)
            else ACCEPTED
        )
        return SideLineDecision(
            final_top,
            final_bottom,
            code,
            points=retained,
            coverage=retained / target_height,
            residual=residual,
        )
    finally:
        if mask is not None:
            mask.close()
        if reduced is not None:
            reduced.close()
        band.close()


def _maximum_outward_move(
    edge: str,
    coarse_top: int,
    coarse_bottom: int,
    final_top: int,
    final_bottom: int,
) -> int:
    if edge == "left":
        return max(coarse_top - final_top, coarse_bottom - final_bottom, 0)
    return max(final_top - coarse_top, final_bottom - coarse_bottom, 0)


def _canvas_tolerance(background: PageBackgroundProfile) -> float:
    return max(14.0, min(38.0, 16.0 + float(background.spread) * 0.32))


def _is_canvas(value: float, background: PageBackgroundProfile, tolerance: float) -> bool:
    return abs(float(value) - float(background.luminance)) <= tolerance


def _canvas_transition_side_line(
    band: Image.Image,
    background: PageBackgroundProfile,
    *,
    coarse_top: int,
    coarse_bottom: int,
    edge: str,
    search: int,
    settings: SideRefineSettings,
) -> tuple[float, float, float, int] | None:
    """Fit a persistent canvas-to-panel boundary on either side of coarse X."""

    width, height = band.size
    if width < 16 or height < 16:
        return None
    gray = band.convert("L")
    try:
        pixels = gray.load()
        tolerance = _canvas_tolerance(background)
        probe = max(2, min(6, int(round(width * 0.0035))))
        maximum_run = max(6, min(48, int(search)))
        points: list[tuple[float, float]] = []
        denominator = max(1, height - 1)

        for y in range(height):
            fraction = y / denominator
            predicted = float(coarse_top) + (
                float(coarse_bottom) - float(coarse_top)
            ) * fraction
            center = int(round(predicted))
            start = max(probe, center - int(search))
            end = min(width - probe, center + int(search))
            if end <= start:
                continue

            best: tuple[tuple[float, float, float, float], int] | None = None
            for x in range(start, end + 1):
                if edge == "left":
                    outside_values = [float(pixels[sx, y]) for sx in range(x - probe, x)]
                    inside_values = [float(pixels[sx, y]) for sx in range(x, x + probe)]
                    run = _canvas_run_length(
                        pixels,
                        y,
                        x - 1,
                        step=-1,
                        limit=maximum_run,
                        width=width,
                        background=background,
                        tolerance=tolerance,
                    )
                else:
                    inside_values = [float(pixels[sx, y]) for sx in range(x - probe, x)]
                    outside_values = [float(pixels[sx, y]) for sx in range(x, x + probe)]
                    run = _canvas_run_length(
                        pixels,
                        y,
                        x,
                        step=1,
                        limit=maximum_run,
                        width=width,
                        background=background,
                        tolerance=tolerance,
                    )

                outside_fraction = sum(
                    _is_canvas(value, background, tolerance)
                    for value in outside_values
                ) / len(outside_values)
                inside_fraction = sum(
                    _is_canvas(value, background, tolerance)
                    for value in inside_values
                ) / len(inside_values)
                if outside_fraction < 0.75 or inside_fraction > 0.35 or run < 2:
                    continue
                outside_mean = sum(outside_values) / len(outside_values)
                inside_mean = sum(inside_values) / len(inside_values)
                contrast = abs(outside_mean - inside_mean)
                if contrast < 16.0:
                    continue
                distance = abs(float(x) - predicted)
                score = (
                    float(min(run, 32)),
                    float(outside_fraction - inside_fraction),
                    float(contrast),
                    -distance,
                )
                if best is None or score > best[0]:
                    best = (score, x)
            if best is not None:
                points.append((float(y), float(best[1])))

        minimum_fraction = max(0.38, float(settings.minimum_coverage) * 0.80)
        minimum_points = max(12, int(ceil(height * minimum_fraction)))
        if len(points) < minimum_points:
            return None
        return _fit_line(
            points,
            height,
            minimum_points=minimum_points,
            maximum_residual=max(2.0, float(settings.maximum_residual_source)),
        )
    finally:
        gray.close()


def _canvas_run_length(
    pixels,
    y: int,
    start: int,
    *,
    step: int,
    limit: int,
    width: int,
    background: PageBackgroundProfile,
    tolerance: float,
) -> int:
    run = 0
    x = int(start)
    while 0 <= x < width and run < limit:
        if not _is_canvas(float(pixels[x, y]), background, tolerance):
            break
        run += 1
        x += int(step)
    return run


def _page_edge_continuation_support(
    band: Image.Image,
    background: PageBackgroundProfile,
    *,
    edge: str,
    coarse_top: int,
    coarse_bottom: int,
) -> bool:
    """Return whether a single panel visibly continues to the physical page edge."""

    width, height = band.size
    if width < 16 or height < 16:
        return False
    edge_distance = (
        min(coarse_top, coarse_bottom)
        if edge == "left"
        else width - max(coarse_top, coarse_bottom)
    )
    significant = max(8, int(round(width * 0.012)))
    if edge_distance <= significant:
        return False

    gray = band.convert("L")
    try:
        pixels = gray.load()
        tolerance = _canvas_tolerance(background)
        edge_probe = max(4, min(24, int(round(width * 0.018))))
        denominator = max(1, height - 1)
        eligible = 0
        edge_good = 0
        bridge_good = 0

        for y in range(height):
            fraction = y / denominator
            boundary = int(
                round(
                    float(coarse_top)
                    + (float(coarse_bottom) - float(coarse_top)) * fraction
                )
            )
            if edge == "left":
                span_start = 0
                span_end = max(0, min(width, boundary - 2))
                edge_start = 0
                edge_end = min(width, edge_probe)
            else:
                span_start = max(0, min(width, boundary + 2))
                span_end = width
                edge_start = max(0, width - edge_probe)
                edge_end = width
            if span_end - span_start < significant:
                continue

            eligible += 1
            edge_values = [float(pixels[x, y]) for x in range(edge_start, edge_end)]
            edge_non_canvas = sum(
                not _is_canvas(value, background, tolerance)
                for value in edge_values
            ) / max(1, len(edge_values))
            if edge_non_canvas >= 0.62:
                edge_good += 1

            span = span_end - span_start
            sample_count = max(8, min(24, span))
            xs = tuple(
                span_start + round(index * (span - 1) / (sample_count - 1))
                for index in range(sample_count)
            )
            non_canvas = sum(
                not _is_canvas(float(pixels[x, y]), background, tolerance)
                for x in xs
            ) / sample_count
            if non_canvas >= 0.52:
                bridge_good += 1

        minimum_rows = max(12, int(round(height * 0.36)))
        if eligible < minimum_rows:
            return False
        return edge_good / eligible >= 0.62 and bridge_good / eligible >= 0.56
    finally:
        gray.close()


def _page_edge_canvas_support(
    band: Image.Image,
    background: PageBackgroundProfile,
    *,
    edge: str,
    coarse_top: int,
    coarse_bottom: int,
    final_top: int,
    final_bottom: int,
) -> bool:
    """Require real page-canvas evidence before trimming a physical page edge."""

    width, height = band.size
    if width < 16 or height < 16 or edge not in {"left", "right"}:
        return False

    if edge == "left":
        movement_top = final_top - coarse_top
        movement_bottom = final_bottom - coarse_bottom
    else:
        movement_top = coarse_top - final_top
        movement_bottom = coarse_bottom - final_bottom

    significant = max(10, int(round(width * 0.012)))
    if max(movement_top, movement_bottom) <= significant:
        return True

    gray = band.convert("L")
    try:
        pixels = gray.load()
        denominator = max(1, height - 1)
        canvas = float(background.luminance)
        luminance_tolerance = 16.0
        good_rows = 0
        eligible_rows = 0

        for y in range(height):
            fraction = y / denominator
            boundary = int(
                round(
                    float(final_top)
                    + (float(final_bottom) - float(final_top)) * fraction
                )
            )
            if edge == "left":
                start = 0
                end = max(0, min(width, boundary - 2))
            else:
                start = max(0, min(width, boundary + 2))
                end = width

            span = end - start
            if span < significant:
                continue

            sample_count = max(8, min(24, span))
            xs = tuple(
                start + round(index * (span - 1) / (sample_count - 1))
                for index in range(sample_count)
            )
            canvas_hits = sum(
                abs(float(pixels[x, y]) - canvas) <= luminance_tolerance
                for x in xs
            )
            eligible_rows += 1
            if canvas_hits / sample_count >= 0.72:
                good_rows += 1

        minimum_rows = max(12, int(round(height * 0.30)))
        if eligible_rows < minimum_rows:
            return False
        return good_rows / eligible_rows >= 0.62
    finally:
        gray.close()


def refine_panel_sides(
    source: Image.Image,
    background: PageBackgroundProfile,
    panels: tuple[PanelHypothesis, ...],
    settings: FrameAnalysisSettings,
    diagnostics: DiagnosticsCollector | None = None,
) -> tuple[PanelHypothesis, ...]:
    config = settings.normalized().side_refine
    output: list[PanelHypothesis] = []

    # A true same-row split has internal sides that must never expand to the
    # page edge, but its two outer sides still belong to the page geometry.
    # 0.5.3 disabled page-edge recovery for the whole same-row group, so a
    # borderless outer panel could remain clipped at a false internal coarse-X.
    row_members: dict[int, list[int]] = {}
    for panel_index, candidate in enumerate(panels):
        row_members.setdefault(int(candidate.row_index), []).append(panel_index)
    row_leftmost: dict[int, int] = {}
    row_rightmost: dict[int, int] = {}
    for row_index, member_indices in row_members.items():
        row_leftmost[row_index] = min(
            member_indices,
            key=lambda member_index: (
                min(
                    panels[member_index].left_top,
                    panels[member_index].left_bottom,
                ),
                member_index,
            ),
        )
        row_rightmost[row_index] = max(
            member_indices,
            key=lambda member_index: (
                max(
                    panels[member_index].right_top,
                    panels[member_index].right_bottom,
                ),
                -member_index,
            ),
        )

    for index, panel in enumerate(panels):
        single_panel = str(panel.split_decision) == "single"
        row_index = int(panel.row_index)
        left_page_edge_recovery = (
            single_panel or index == row_leftmost[row_index]
        )
        right_page_edge_recovery = (
            single_panel or index == row_rightmost[row_index]
        )
        left = source_resolution_side_line(
            source,
            background,
            top=panel.top,
            bottom=panel.bottom,
            coarse_top=panel.left_top,
            coarse_bottom=panel.left_bottom,
            edge="left",
            settings=config,
            allow_page_edge_recovery=left_page_edge_recovery,
        )
        right = source_resolution_side_line(
            source,
            background,
            top=panel.top,
            bottom=panel.bottom,
            coarse_top=panel.right_top,
            coarse_bottom=panel.right_bottom,
            edge="right",
            settings=config,
            allow_page_edge_recovery=right_page_edge_recovery,
        )
        left_top, left_bottom = (
            (left.top, left.bottom)
            if left.resolved
            else (panel.left_top, panel.left_bottom)
        )
        right_top, right_bottom = (
            (right.top, right.bottom)
            if right.resolved
            else (panel.right_top, panel.right_bottom)
        )
        assert left_top is not None and left_bottom is not None
        assert right_top is not None and right_bottom is not None

        codes = (f"left:{left.code}", f"right:{right.code}")
        if (
            int(right_top) - int(left_top) < config.minimum_frame_width_source
            or int(right_bottom) - int(left_bottom) < config.minimum_frame_width_source
        ):
            codes = (*codes, MINIMUM_FRAME_WIDTH)
            resolved = replace(panel, reason_codes=(*panel.reason_codes, *codes))
        else:
            accepted_codes = {
                ACCEPTED,
                OUTWARD_RULE_ACCEPTED,
                PAGE_EDGE_CONTINUATION_ACCEPTED,
            }
            accepted_count = int(left.code in accepted_codes) + int(right.code in accepted_codes)
            resolved = replace(
                panel,
                left_top=int(left_top),
                left_bottom=int(left_bottom),
                right_top=int(right_top),
                right_bottom=int(right_bottom),
                confidence=min(1.0, panel.confidence + accepted_count * 0.04),
                reason_codes=(*panel.reason_codes, *codes),
            )
        output.append(resolved)

        for edge_name, decision in (("left", left), ("right", right)):
            emit(
                diagnostics,
                "side_refine",
                decision.code,
                f"Source-resolution {edge_name} side decision",
                details={
                    "panel_index": index,
                    "edge": edge_name,
                    "points": decision.points,
                    "coverage": decision.coverage,
                    "residual": decision.residual,
                    "coarse_top": getattr(panel, f"{edge_name}_top"),
                    "coarse_bottom": getattr(panel, f"{edge_name}_bottom"),
                    "final_top": decision.top,
                    "final_bottom": decision.bottom,
                    "page_edge_recovery": (
                        left_page_edge_recovery
                        if edge_name == "left"
                        else right_page_edge_recovery
                    ),
                    "row_outer_side": (
                        index == row_leftmost[row_index]
                        if edge_name == "left"
                        else index == row_rightmost[row_index]
                    ),
                },
            )
    return tuple(output)


def _fit_line(
    points: list[tuple[float, float]],
    height: int,
    *,
    minimum_points: int,
    maximum_residual: float,
) -> tuple[float, float, float, int] | None:
    current = list(points)
    if len(current) < minimum_points:
        return None

    dominant = _dominant_line_seed(
        current,
        height,
        minimum_points=minimum_points,
        maximum_residual=maximum_residual,
    )
    if dominant is not None:
        current = dominant

    if len(current) > 64:
        sample = [
            current[round(index * (len(current) - 1) / 63)]
            for index in range(64)
        ]
    else:
        sample = current
    slopes = [
        (second_x - first_x) / (second_y - first_y)
        for first_index, (first_y, first_x) in enumerate(sample)
        for second_y, second_x in sample[first_index + 1 :]
        if abs(second_y - first_y) >= max(4.0, height * 0.12)
    ]
    slope = float(median(slopes)) if slopes else 0.0
    intercept = float(median([x - slope * y for y, x in current]))
    seed_residuals = [abs(x - (slope * y + intercept)) for y, x in current]
    seed_limit = max(2.0, float(median(seed_residuals)) * 2.8)
    seeded = [
        point
        for point, residual in zip(current, seed_residuals)
        if residual <= seed_limit
    ]
    if len(seeded) >= minimum_points:
        current = seeded

    residual_value = 0.0
    for _iteration in range(4):
        count = len(current)
        if count < minimum_points:
            return None
        mean_y = sum(y for y, _x in current) / count
        mean_x = sum(x for _y, x in current) / count
        denominator = sum((y - mean_y) ** 2 for y, _x in current)
        if denominator <= 1e-9:
            return None
        slope = sum((y - mean_y) * (x - mean_x) for y, x in current) / denominator
        intercept = mean_x - slope * mean_y
        residuals = [abs(x - (slope * y + intercept)) for y, x in current]
        residual_value = float(median(residuals))
        limit = max(2.0, residual_value * 2.8)
        filtered = [
            point
            for point, residual in zip(current, residuals)
            if residual <= limit
        ]
        if len(filtered) < minimum_points:
            return None
        if len(filtered) == len(current):
            break
        current = filtered
    if residual_value > maximum_residual:
        return None
    if (
        min(y for y, _x in current) > max(3.0, height * 0.38)
        or max(y for y, _x in current) < max(0.0, (height - 1) * 0.62)
    ):
        return None
    return (
        intercept,
        slope * max(0, height - 1) + intercept,
        residual_value,
        len(current),
    )


def _dominant_line_seed(
    points: list[tuple[float, float]],
    height: int,
    *,
    minimum_points: int,
    maximum_residual: float,
) -> list[tuple[float, float]] | None:
    if len(points) < minimum_points:
        return None
    sample_count = 40
    if len(points) > sample_count:
        sample = [
            points[round(index * (len(points) - 1) / (sample_count - 1))]
            for index in range(sample_count)
        ]
    else:
        sample = points

    minimum_separation = max(4.0, height * 0.18)
    tolerance = max(2.0, min(float(maximum_residual), 4.0))
    best: list[tuple[float, float]] | None = None
    best_score: tuple[int, float, float] | None = None
    for first_index, (first_y, first_x) in enumerate(sample):
        for second_y, second_x in sample[first_index + 1 :]:
            delta_y = second_y - first_y
            if abs(delta_y) < minimum_separation:
                continue
            slope = (second_x - first_x) / delta_y
            intercept = first_x - slope * first_y
            inliers: list[tuple[float, float]] = []
            residual_sum = 0.0
            for point in points:
                y, x = point
                residual = abs(x - (slope * y + intercept))
                if residual <= tolerance:
                    inliers.append(point)
                    residual_sum += residual
            if len(inliers) < minimum_points:
                continue
            span = max(y for y, _x in inliers) - min(y for y, _x in inliers)
            score = (len(inliers), span, -residual_sum)
            if best_score is None or score > best_score:
                best_score = score
                best = inliers
    return best


__all__ = [
    "ACCEPTED",
    "INSUFFICIENT_COVERAGE",
    "MINIMUM_FRAME_WIDTH",
    "NO_POINTS",
    "OUTWARD_MOVE_REJECTED",
    "OUTWARD_RULE_ACCEPTED",
    "PAGE_EDGE_CANVAS_REJECTED",
    "PAGE_EDGE_CONTINUATION_ACCEPTED",
    "RESIDUAL_TOO_HIGH",
    "SEARCH_LIMIT",
    "SideLineDecision",
    "source_resolution_side_line",
    "refine_panel_sides",
]
