from __future__ import annotations

from PIL import Image, ImageOps

from .background import analyze_background
from .coarse_rows import detect_coarse_rows
from .contract import PageAnalysisResult
from .diagnostics import (
    DiagnosticsCollector,
    FanoutDiagnosticsCollector,
    ListDiagnosticsCollector,
    emit,
)
from .horizontal_split import split_horizontal_panels
from .ordering import assemble_candidates
from .row_rules import refine_rows_at_panel_rules
from .settings import FrameAnalysisSettings
from .side_refine import refine_panel_sides


ENGINE_API = "0.5"
ENGINE_VERSION = "0.5.4"
ENGINE_CHANGELOG = (
    "Крайние панели горизонтальной same-row группы теперь могут восстанавливать свою внешнюю сторону до физического края страницы, если source-resolution проверка подтверждает непрерывное содержимое.",
    "Правый borderless кадр больше не останавливается на внутренней тёмной массе персонажа, когда изображение продолжается до правого края страницы.",
    "Внутренние стороны настоящих соседних кадров по-прежнему не получают page-edge recovery и остаются защищены от ложного расширения.",
)


def analyze_page_v05(
    source_image: Image.Image,
    settings: FrameAnalysisSettings | None = None,
    diagnostics: DiagnosticsCollector | None = None,
) -> PageAnalysisResult:
    """Run the complete 0.5 analyzer without importing Qt or editor state."""

    if not isinstance(source_image, Image.Image):
        raise TypeError("source_image must be a PIL image")
    config = (settings or FrameAnalysisSettings()).normalized()
    captured = ListDiagnosticsCollector()
    collector: DiagnosticsCollector = (
        FanoutDiagnosticsCollector(captured, diagnostics)
        if diagnostics is not None
        else captured
    )

    transposed = ImageOps.exif_transpose(source_image)
    source = transposed.convert("RGB")
    try:
        emit(
            collector,
            "pipeline",
            "ANALYSIS_STARTED",
            "0.5 page analysis started",
            details={"width": source.width, "height": source.height},
        )
        background = analyze_background(source, collector)
        profiles, coarse_rows = detect_coarse_rows(
            source,
            background,
            config,
            collector,
        )
        refined_rows = refine_rows_at_panel_rules(
            source,
            coarse_rows,
            profiles,
            config,
            collector,
        )
        panels = split_horizontal_panels(
            source,
            refined_rows,
            background,
            config,
            collector,
        )
        panels = refine_panel_sides(
            source,
            background,
            panels,
            config,
            collector,
        )
        frames = assemble_candidates(panels, collector)
        emit(
            collector,
            "pipeline",
            "ANALYSIS_FINISHED",
            "0.5 page analysis completed",
            details={"frames": len(frames)},
        )
        return PageAnalysisResult(
            width=source.width,
            height=source.height,
            background=background,
            frames=frames,
            diagnostics=tuple(captured.events),
            engine_api=ENGINE_API,
            engine_version=ENGINE_VERSION,
        )
    finally:
        source.close()
        if transposed is not source_image:
            transposed.close()


__all__ = ["ENGINE_API", "ENGINE_CHANGELOG", "ENGINE_VERSION", "analyze_page_v05"]
